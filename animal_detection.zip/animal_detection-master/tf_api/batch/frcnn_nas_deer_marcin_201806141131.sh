

# deer

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_1_1 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_1_2 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_1_3 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_1_4 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_2_2
/data/acamp/marcin_180613/deer_2_4 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_3_1 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_3_2 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_3_3 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_4_1 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_4_2 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_5_1 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_6_1 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_6_2 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_6_3 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_6_4 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_7_1 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_8_1 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/faster_rcnn_nas_coco_2018_01_28/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/data/acamp/marcin_180613/deer_8_2 save_dir=results/faster_rcnn_nas_coco_2018_01_28/ n_frames=0 batch_size=2
