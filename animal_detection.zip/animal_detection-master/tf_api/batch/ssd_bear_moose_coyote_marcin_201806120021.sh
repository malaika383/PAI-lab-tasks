
### marcin_180608

#### bear

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/bear_1_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/bear_1_2 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/bear_1_3 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/bear_1_4 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/bear_1_5 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/bear_1_6 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/bear_2 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/bear_3 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/bear_4 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/bear_5 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/grizzly_bear_6_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

#### moose

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_1_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_1_2 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_2_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_2_2 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_4_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_4_2 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_4_3 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_5_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_5_2 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_5_3 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_5_4 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_5_5 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_5_6 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_5_7 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_5_8 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_5_9 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_5_10 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_5_12 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_5_13 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_6_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_6_2 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_6_3 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_7_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_8_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_9_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_10_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_10_2 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_11_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_12_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_12_2 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_12_3 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/moose_13_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

#### coyote

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/coyote_1_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/coyote_1_2 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/coyote_1_3 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/coyote_2_1 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25

CUDA_VISIBLE_DEVICES=1 python3 test.py ckpt_path=trained/ssd_inception_v2_coco_2017_11_17/inference/frozen_inference_graph.pb labels_path=data/wildlife_label_map.pbtxt file_name=/home/abhineet/acamp/acamp_code/object_detection/videos/marcin/coyote_2_2 save_dir=results/ssd_inception_v2_coco_2017_11_17/ n_frames=0 batch_size=25
