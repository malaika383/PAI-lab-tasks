CUDA_VISIBLE_DEVICES=0 python3 test.py model_list=trained_models.txt model_id=17 list_file_name=acamp40k3_test_no_human.txt root_dir=/data/acamp/acamp20k n_frames=0 batch_size=25 n_classes=3
CUDA_VISIBLE_DEVICES=0 python3 test.py model_list=trained_models.txt model_id=18 list_file_name=acamp40k3_test_no_human.txt root_dir=/data/acamp/acamp20k n_frames=0 batch_size=25 n_classes=3
CUDA_VISIBLE_DEVICES=0 python3 test.py model_list=trained_models.txt model_id=19 list_file_name=acamp40k3_test_no_human.txt root_dir=/data/acamp/acamp20k n_frames=0 batch_size=25 n_classes=3
CUDA_VISIBLE_DEVICES=0 python3 test.py model_list=trained_models.txt model_id=20 list_file_name=acamp40k3_test_no_human.txt root_dir=/data/acamp/acamp20k n_frames=0 batch_size=25 n_classes=3
CUDA_VISIBLE_DEVICES=0 python3 test.py model_list=trained_models.txt model_id=21 list_file_name=acamp40k3_test_no_human.txt root_dir=/data/acamp/acamp20k n_frames=0 batch_size=25 n_classes=3
