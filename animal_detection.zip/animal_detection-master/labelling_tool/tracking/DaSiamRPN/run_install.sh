pip install --upgrade pip
pip install numpy
pip install opencv-python
pip install http://download.pytorch.org/whl/cu80/torch-0.3.1-cp27-cp27mu-linux_x86_64.whl
