from flask import Flask, render_template, request, redirect, url_for
from models import init_db, get_all_recipes, add_recipe, delete_recipe

app = Flask(__name__)
init_db()

@app.route('/')
def index():
    recipes = get_all_recipes()
    return render_template('index.html', recipes=recipes)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        title = request.form['title']
        ingredients = request.form['ingredients']
        instructions = request.form['instructions']
        add_recipe(title, ingredients, instructions)
        return redirect(url_for('index'))
    return render_template('add.html')

@app.route('/delete/<int:recipe_id>')
def delete(recipe_id):
    delete_recipe(recipe_id)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
