import sqlite3

def init_db():
    conn = sqlite3.connect('recipes.db')
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS recipes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            ingredients TEXT NOT NULL,
            instructions TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

def get_all_recipes():
    conn = sqlite3.connect('recipes.db')
    c = conn.cursor()
    c.execute('SELECT * FROM recipes')
    recipes = c.fetchall()
    conn.close()
    return recipes

def add_recipe(title, ingredients, instructions):
    conn = sqlite3.connect('recipes.db')
    c = conn.cursor()
    c.execute('INSERT INTO recipes (title, ingredients, instructions) VALUES (?, ?, ?)',
              (title, ingredients, instructions))
    conn.commit()
    conn.close()

def delete_recipe(recipe_id):
    conn = sqlite3.connect('recipes.db')
    c = conn.cursor()
    c.execute('DELETE FROM recipes WHERE id = ?', (recipe_id,))
    conn.commit()
    conn.close()
